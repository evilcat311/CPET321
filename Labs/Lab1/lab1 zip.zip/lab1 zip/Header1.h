#pragma once
bool check_validity(int checksum);
int calculate_checksum(int card[]);
int read_card_number(void);